
export const add = (a, b) => a + b;